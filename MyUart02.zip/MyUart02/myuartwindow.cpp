#include "myuartwindow.h"
#include "ui_myuartwindow.h"
#include <QGridLayout>
MyUartWindow::MyUartWindow(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::MyUartWindow)
{
    ui->setupUi(this);
    //初始化串口
    initSeialPort();
    count1=5;
    value1=25;
    count2=8;
    value2=25;
    count3=9;
    value3=25;
    //初始化charts
   // QPointF *mypoint =new QPointF(15,15.2);
    lineseries01= new QLineSeries();
    //lineseries01->append(*mypoint);
    //bool ok;
    lineseries01->append(0,0);
    lineseries01->append(count1,value1);
    lineseries01->append(count2,value2);
    lineseries01->append(count3,value3);
   // lineseries01->append(requestData.toInt(&ok, 10)-20,requestData.toInt(&ok, 10));
    //lineseries01->append(value,count);
    QChart *chart = new QChart();
    chart->legend()->hide();
    chart->addSeries(lineseries01);// 将 series 添加进去
    chart->setTitle("实时温度折线统计图");
    // x,y轴
    QValueAxis *axisX = new QValueAxis;

    axisX->setRange(0,250);
    QValueAxis *axisY = new QValueAxis;
    axisY->setRange(0.0,35.00);
    chart->setAxisX(axisX,lineseries01);
    chart->setAxisY(axisY,lineseries01);

    //画布
    QChartView *chartView = new QChartView(chart);
    chartView->setRenderHint(QPainter::Antialiasing);
    ui->gridLayout_chart->addWidget(chartView);
    initcharts();
}

MyUartWindow::~MyUartWindow()
{
    delete ui;
    delete lineseries01;
    delete mycharts;
}
void MyUartWindow::initcharts()
{

}
void MyUartWindow::initSeialPort()
{
    foreach( const QSerialPortInfo &Info,QSerialPortInfo::availablePorts())//读取串口信息
        {
            qDebug() << "portName    :"  << Info.portName();//调试时可以看的串口信息
            qDebug() << "Description   :" << Info.description();
            qDebug() << "Manufacturer:" << Info.manufacturer();

            serial.setPort(Info);

            if( serial.open( QIODevice::ReadWrite) )//如果串口是可以读写方式打开的
            {
                ui->comboBox_com->addItem( Info.portName() );//在comboBox那添加串口号
                serial.close();//然后自动关闭等待人为开启（通过那个打开串口的PushButton）
            }
        }
}


void MyUartWindow::on_pushButton_send_clicked()
{
    my_serialPort->write( ui->lineEdit->text().toUtf8() );
    //ui->textEdit->setText(ui->lineEdit->text());
    ui->textEdit->append(ui->lineEdit->text());
}

void MyUartWindow::on_pushButton_open_clicked()
{
    my_serialPort = new QSerialPort(this);//栈区开辟 指针空间
    my_serialPort->setPortName( ui->comboBox_com->currentText() );
    my_serialPort->open( QIODevice::ReadWrite );// 用只读的 方式 打开串口
    qDebug() << ui->comboBox_com->currentText();
    // currentText().toInt()
    /*
     * toInt() 为QByteArray 类的 方法， 即将组合框的当前文本 Qstring 类型的数据 写为int 型
    */
    my_serialPort->setBaudRate(  ui->comboBox_bord->currentText().toInt() );//波特率 调用设置波特率
    //检测currenText文本的字符类型
    my_serialPort->setDataBits( QSerialPort::Data8 );//数据字节，8字节
    my_serialPort->setParity( QSerialPort::NoParity );//校验，无
    my_serialPort->setFlowControl( QSerialPort::NoFlowControl );//数据流控制,无
    my_serialPort->setStopBits( QSerialPort::OneStop );//一位停止位

    timer01 = new QTimer(this);
    connect( timer01, SIGNAL( timeout() ), this, SLOT( serialRead() ) );//时间溢出则发送溢出 信号串口读取函数进行 读取 消息
    timer01->start(3000);//每秒读一次 每秒太快 改成三秒 否则轴建立 会影响重绘
}
void MyUartWindow::serialRead()
{
    requestData = my_serialPort->readAll();//用requestData存储从串口那读取的数据
    //value=(requestData[1]-'0')*10+(requestData[2]-'0');
    // 写一个字符串比较函数 利用帧头和 帧尾 提取需要的数值 这里是根据 数据帧 数字字符的位置
    value=(requestData[5]-'0')*10+(requestData[6]-'0');
   // QPoint *newpoint= new QPoint(count,value);
    count=count2+5;
    qDebug()<<count2;

   //lineseries01->append(count,value);
    lineseries01->replace(count3,value3,count,value);// 替换 原来的点 实现动态刷新
    lineseries01->replace(count2,value2,count3,value3);
    lineseries01->replace(count1,value1,count2,value2);
    count3=count;
    value3=value;

    count2=count3;
    value2=value3;
    count1=count2;
    value1=value2;
\
   qDebug()<<requestData;
   qDebug()<<requestData[0];
   qDebug()<<requestData[1];
   ui->textEdit->append(requestData);// 将缓冲区的字符 写入 textEdit
   requestData.clear();    //清除缓冲区
    //qDebug()<<requestData[2];
    //qDebug()<<requestData[3];

    //int value= (requestData[1]-'0')*10;
    //qDebug()<<value;
    //initcharts();
    //  QByteArray requestData
    //ui->textEdit->append(requestData);// 串口读取缓冲区  数据

}
void MyUartWindow::on_pushButton_clear_clicked()
{
    ui->lineEdit->clear();
}

void MyUartWindow::on_pushButton_cleartext_clicked()
{
    ui->textEdit->clear();
}

void MyUartWindow::on_pushButton_off_clicked()
{
    my_serialPort->close();
    ui->textEdit->append("串口已关闭");
}

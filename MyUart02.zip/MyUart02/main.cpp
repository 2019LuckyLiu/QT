#include "myuartwindow.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MyUartWindow w;
    w.setWindowTitle("串口助手——lcj");
   // w.resize(600,500);
    w.show();
  //  w.setLayout()
    return a.exec();
}

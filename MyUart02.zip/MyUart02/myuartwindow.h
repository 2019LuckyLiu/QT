#ifndef MYUARTWINDOW_H
#define MYUARTWINDOW_H

#include <QWidget>
#include <QSerialPort>        //提供访问串口的功能
#include <QSerialPortInfo>    //提供系统中存在的串口的信息 Info 向导
#include <QDebug>
#include <QTimer>
#include <QList>
#include <QtCharts/QChartView>
#include<QLineSeries>
#include <QValueAxis>
#include <QPointF>// 浮点型 QPoint
QT_CHARTS_USE_NAMESPACE

namespace Ui {
class MyUartWindow;
}

class MyUartWindow : public QWidget
{
    Q_OBJECT

public:
    explicit MyUartWindow(QWidget *parent = nullptr);
    ~MyUartWindow();
private slots:

    void serialRead();//串口 读取显示函数

    void on_pushButton_send_clicked();


    void on_pushButton_open_clicked();

    void on_pushButton_clear_clicked();

    void on_pushButton_cleartext_clicked();

    void on_pushButton_off_clicked();

private:
    void initcharts();

private:
    Ui::MyUartWindow *ui;
    //charts 折线图
    int value;
    int count;
    int value1;
    int count1;
    int value2;
    int count2;
    int value3;
    int count3;
    QLineSeries *lineseries01;// 必需包含 charts 的 space空间
    QChart *mycharts;
    QList<QPointF> *listpointf;
    //串口
    QTimer *timer01;
    QSerialPort *my_serialPort;//(实例化一个指向串口的指针，可以用于访问串口)
    QByteArray requestData;//（用于存储从串口那读取的数据）
    QSerialPort serial;
    void initSeialPort();// 串口初始化 检测电脑的 端口
};

#endif // MYUARTWINDOW_H
